# team_config.py
# Team 305 EGR314 shared protocol constants for Liam's LED test node

PKT_LEN = 64
PREFIX = (0xA5, 0x5A)
SUFFIX = (0x59, 0x42)

RESERVED_TEAM = (0xA5, 0x5A, 0x59, 0x42)

# Liam's original test file had no node-specific reserved byte,
# so 0x23 is assigned here for his local bench-test copy.
RESERVED_NODE = {
    0x43: None,  # Christo
    0x4C: None,  # Liam
    0x49: None,  # Isaiah
    0x41: None,  # Arianna
    0x4D: None,  # Myles
    0x52: None,  # Ragul
    0x44: None,  # Damian
}


def reserved_bytes_for(node_id):
    extra = RESERVED_NODE.get(node_id)
    if extra is not None:
        return RESERVED_TEAM + (extra,)
    return RESERVED_TEAM


HMI_ID = 0x43
MY_ID = 0x4C
LIAM_ID = 0x4C
ISAIAH_ID = 0x49
ARIANNA_ID = 0x41
MYLES_ID = 0x4D
RAGUL_ID = 0x52
DAMIAN_ID = 0x44
BCAST = 0x58

KNOWN_IDS = (
    HMI_ID,
    LIAM_ID,
    ISAIAH_ID,
    ARIANNA_ID,
    MYLES_ID,
    RAGUL_ID,
    DAMIAN_ID,
    BCAST,
)

BAUD_RATE = 9600
MSG_MOTOR_SPEED = 0x01
MSG_STOP = 0x02
MSG_REQUEST = 0x14
ACK_TYPE = 0xAA
