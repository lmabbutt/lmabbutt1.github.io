# motor_driver.py
# Team 305 EGR314 - Liam - IFX9201SG motor driver node
# Motor B: PWM=GPIO4, DIR=GPIO5, DIS=GPIO6, CSN=GPIO39
# SPI: SCK=GPIO12, MOSI=GPIO11, MISO=GPIO13
# UART1: TX=GPIO17, RX=GPIO16
# LED: GPIO47

from machine import UART, Pin, PWM, SPI
import time

from team_config import (
    BAUD_RATE, HMI_ID, LIAM_ID, MSG_MOTOR_SPEED,
    MSG_STOP, ACK_TYPE
)
from uart_protocol import build_ack, route_packet, UARTReceiver

# ============================================================
# LED
# ============================================================
led = Pin(47, Pin.OUT)
led.value(0)
_led_on = False
_last_blink = time.ticks_ms()
_BLINK_MS = 200

# ============================================================
# UART
# ============================================================
UART_TX_PIN = 17
UART_RX_PIN = 16
uart = UART(1, baudrate=BAUD_RATE, tx=Pin(UART_TX_PIN), rx=Pin(UART_RX_PIN))
uart_rx = UARTReceiver()

# ============================================================
# SPI BUS - Mode 1 (CPOL=0, CPHA=1) per IFX9201SG datasheet
# ============================================================
spi = SPI(1,
    baudrate=1000000,
    polarity=0,
    phase=1,
    bits=8,
    firstbit=SPI.MSB,
    sck=Pin(12),
    mosi=Pin(11),
    miso=Pin(13))

# ============================================================
# MOTOR B PINS
# ============================================================
motor_b_csn = Pin(39, Pin.OUT)
motor_b_pwm = PWM(Pin(4), freq=20000)
motor_b_dis = Pin(6, Pin.OUT)

# Initialise Motor B
motor_b_csn.value(1)   # Deselect — CSN high = PWM/DIR mode
motor_b_dis.off()      # DIS low = outputs enabled

# ============================================================
# SPI COMMANDS per datasheet Table 4-2
# ============================================================
CMD_RD_DIA         = 0x00   # 000x xxxx Read Diagnosis Register
CMD_RES_DIA        = 0x80   # 100x xxxx Reset Diagnosis Register
CMD_RD_REV         = 0x20   # 001x xxxx Read Device Revision
CMD_RD_CTRL        = 0x60   # 011x xxxx Read Control Register
CMD_WR_CTRL        = 0xE0   # 111d dddd Write Control Register
CMD_WR_CTRL_RD_DIA = 0xC0   # 110d dddd Write Control Read Diagnosis

# ============================================================
# SPI FUNCTIONS
# ============================================================
def spi_transfer(csn_pin, tx_byte):
    tx_buf = bytearray([tx_byte])
    rx_buf = bytearray(1)
    csn_pin.value(0)
    time.sleep_us(1)
    spi.write_readinto(tx_buf, rx_buf)
    time.sleep_us(1)
    csn_pin.value(1)
    time.sleep_us(10)
    return rx_buf[0]

def read_diagnosis(csn_pin):
    return spi_transfer(csn_pin, CMD_RD_DIA)

def reset_diagnosis(csn_pin):
    return spi_transfer(csn_pin, CMD_RES_DIA)

def read_revision(csn_pin):
    return spi_transfer(csn_pin, CMD_RD_REV)

def write_ctrl(csn_pin, sin, sen, sdir, spwm, oldis=0):
    ctrl_byte = CMD_WR_CTRL
    if oldis: ctrl_byte |= (1 << 4)
    if sin:   ctrl_byte |= (1 << 3)
    if sen:   ctrl_byte |= (1 << 2)
    if sdir:  ctrl_byte |= (1 << 1)
    if spwm:  ctrl_byte |= (1 << 0)
    return spi_transfer(csn_pin, ctrl_byte)

def write_ctrl_read_dia(csn_pin, sin, sen, sdir, spwm, oldis=0):
    ctrl_byte = CMD_WR_CTRL_RD_DIA
    if oldis: ctrl_byte |= (1 << 4)
    if sin:   ctrl_byte |= (1 << 3)
    if sen:   ctrl_byte |= (1 << 2)
    if sdir:  ctrl_byte |= (1 << 1)
    if spwm:  ctrl_byte |= (1 << 0)
    return spi_transfer(csn_pin, ctrl_byte)

def decode_diag(raw):
    dia = raw & 0x0F
    fault_map = {
        0xF: "no_failure",
        0xE: "scg_out1",
        0xD: "scvs_out1",
        0xC: "open_load",
        0xB: "scg_out2",
        0xA: "scg_out1_out2",
        0x9: "scvs1_scg2",
        0x7: "scvs_out2",
        0x6: "scg1_scvs2",
        0x5: "scvs_out1_out2",
        0x3: "vs_undervoltage",
    }
    return {
        "raw": raw,
        "enabled":          bool(raw & 0x80),
        "overtemp_ok":      bool(raw & 0x40),
        "current_limit_ok": bool(raw & 0x10),
        "fault": fault_map.get(dia, "invalid_diag_{:X}".format(dia)),
    }

# ============================================================
# MOTOR CONTROL
# ============================================================
motor_speed = 0

def _set_motor(speed):
    """
    speed: -100 to +100
    positive = forward, negative = reverse, 0 = stop
    """
    global motor_speed
    motor_speed = speed

    # Step 1 - zero PWM before changing direction per datasheet
    motor_b_pwm.duty_u16(0)
    time.sleep_ms(1)

    if speed > 0:
        # Forward
        write_ctrl(motor_b_csn, sin=1, sen=1, sdir=1, spwm=1)
        motor_b_pwm.duty_u16(speed * 65535 // 100)
    elif speed < 0:
        # Reverse
        write_ctrl(motor_b_csn, sin=1, sen=1, sdir=0, spwm=1)
        motor_b_pwm.duty_u16((-speed) * 65535 // 100)
    else:
        # Stop
        write_ctrl(motor_b_csn, sin=1, sen=0, sdir=0, spwm=0)

    # Poll SPI diagnosis after every motor command
    _poll_spi()

def _poll_spi(force=False):
    raw = read_diagnosis(motor_b_csn)
    diag = decode_diag(raw)
    if force or diag["fault"] != "no_failure":
        print("[SPI DIA] raw=0x{:02X} en={} ot_ok={} cl_ok={} fault={}".format(
            diag["raw"],
            int(diag["enabled"]),
            int(diag["overtemp_ok"]),
            int(diag["current_limit_ok"]),
            diag["fault"]))

def _clamp_speed(value):
    if value > 100:  return 100
    if value < -100: return -100
    return value

def _signed_int8(value):
    if value > 127:
        return value - 256
    return value

# ============================================================
# UART MESSAGE HANDLERS
# ============================================================
def _handle_msg(msg_type, payload, sender):
    global motor_speed

    if msg_type == MSG_MOTOR_SPEED:
        if sender == HMI_ID:
            requested = 0
            if payload:
                requested = _signed_int8(payload[0])
            speed = _clamp_speed(requested)
            direction = "FWD" if speed >= 0 else "REV"
            print("[CMD] 0x{:02X}->0x{:02X} speed={} dir={}".format(
                sender, LIAM_ID, abs(speed), direction))
            _set_motor(speed)
        else:
            print("[IGN] motor cmd from non-HMI sender=0x{:02X}".format(sender))

    elif msg_type == MSG_STOP:
        print("[STOP] motor halted by 0x{:02X}".format(sender))
        _set_motor(0)
        reset_diagnosis(motor_b_csn)
        _poll_spi(force=True)

    elif msg_type == ACK_TYPE:
        print("[ACK RX] for type=0x{:02X}".format(payload[0] if payload else 0))

    else:
        print("[NODE] type=0x{:02X} from=0x{:02X} ignored".format(msg_type, sender))

def _send_ack(dest, msg_type):
    if msg_type == ACK_TYPE:
        return
    pkt = build_ack(dest, msg_type)
    if pkt:
        uart.write(pkt)
        print("[ACK TX] to=0x{:02X} for=0x{:02X}".format(dest, msg_type))

def _forward(pkt):
    uart.write(pkt)
    print("[FWD] 0x{:02X}->0x{:02X}".format(pkt[2], pkt[3]))

# ============================================================
# STARTUP
# ============================================================
print("=== Team 305 Liam motor node ready (IFX9201SG) ===")
print("Bus: UART1 @ {} baud TX=GPIO{} RX=GPIO{}".format(
    BAUD_RATE, UART_TX_PIN, UART_RX_PIN))
print("Motor B: PWM=GPIO4 DIR=GPIO5 DIS=GPIO6 CSN=GPIO39")
print("SPI: SCK=GPIO12 MOSI=GPIO11 MISO=GPIO13")

# Read revision and initial diagnosis
rev = read_revision(motor_b_csn)
print("[SPI] init rev=0x{:02X}".format(rev))
_poll_spi(force=True)
reset_diagnosis(motor_b_csn)

# ============================================================
# MAIN LOOP
# ============================================================
while True:

    # Process incoming UART packets
    for raw_pkt in uart_rx.feed(uart):
        print("[RX] 0x{:02X}->0x{:02X} type=0x{:02X}".format(
            raw_pkt[2], raw_pkt[3], raw_pkt[4]))
        route_packet(
            raw_pkt,
            handle_fn=_handle_msg,
            send_ack_fn=_send_ack,
            forward_fn=_forward)

    # Blink LED while motor is running
    now = time.ticks_ms()
    if motor_speed != 0:
        if time.ticks_diff(now, _last_blink) >= _BLINK_MS:
            _led_on = not _led_on
            led.value(_led_on)
            _last_blink = now
    else:
        if _led_on:
            _led_on = False
            led.value(0)

    time.sleep_ms(5)