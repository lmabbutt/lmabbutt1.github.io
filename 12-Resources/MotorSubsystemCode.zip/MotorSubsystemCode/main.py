# main.py
import time

time.sleep_ms(3000)

try:
    import motor_driver
except KeyboardInterrupt:
    print("Stopped at boot")
