from machine import Pin, PWM
from time import sleep

DIR_PIN = 5
PWM_PIN = 18
PWM_FREQ = 1000
LOW_DUTY = 13107  # 20%
MID_DUTY = 26214  # 40%
OFF = 0


dir_pin = Pin(DIR_PIN, Pin.OUT, value=0)
pwm = PWM(Pin(PWM_PIN), freq=PWM_FREQ, duty_u16=OFF)


def stop(seconds=1.0):
    pwm.duty_u16(OFF)
    sleep(seconds)


def drive(direction: int, duty: int, seconds: float):
    dir_pin.value(1 if direction else 0)
    pwm.duty_u16(duty)
    sleep(seconds)


print("continuous motor test start")
print("GPIO5=DIR GPIO18=PWM DIS must be tied to GND")
stop(2)

while True:
    print("forward 20%")
    drive(0, LOW_DUTY, 4)
    stop(2)

    print("reverse 20%")
    drive(1, LOW_DUTY, 4)
    stop(2)

    print("forward 40%")
    drive(0, MID_DUTY, 3)
    stop(2)

    print("reverse 40%")
    drive(1, MID_DUTY, 3)
    stop(3)
